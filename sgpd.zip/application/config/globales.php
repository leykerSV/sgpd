<?php

// Create customized config variables
$config['emailbackoffice']= 'backoffice@cocyar.com ';
$config['emailsistema']= 'sgpdcocyar@gmail.com';

?>