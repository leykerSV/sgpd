<?php echo form_open('doccomercial/add',array("class"=>"form-horizontal")); ?>

	<div class="form-group">
		<label for="inscripcion" class="col-md-4 control-label">Inscripcion</label>
		<div class="col-md-8">
			<input type="text" name="inscripcion" value="<?php echo $this->input->post('inscripcion'); ?>" class="form-control" id="inscripcion" />
		</div>
	</div>
	<div class="form-group">
		<label for="inscripcionobs" class="col-md-4 control-label">Inscripcionobs</label>
		<div class="col-md-8">
			<input type="text" name="inscripcionobs" value="<?php echo $this->input->post('inscripcionobs'); ?>" class="form-control" id="inscripcionobs" />
		</div>
	</div>
	<div class="form-group">
		<label for="inscripcionok" class="col-md-4 control-label">Inscripcionok</label>
		<div class="col-md-8">
			<input type="text" name="inscripcionok" value="<?php echo $this->input->post('inscripcionok'); ?>" class="form-control" id="inscripcionok" />
		</div>
	</div>
	<div class="form-group">
		<label for="balance" class="col-md-4 control-label">Balance</label>
		<div class="col-md-8">
			<input type="text" name="balance" value="<?php echo $this->input->post('balance'); ?>" class="form-control" id="balance" />
		</div>
	</div>
	<div class="form-group">
		<label for="balanceobs" class="col-md-4 control-label">Balanceobs</label>
		<div class="col-md-8">
			<input type="text" name="balanceobs" value="<?php echo $this->input->post('balanceobs'); ?>" class="form-control" id="balanceobs" />
		</div>
	</div>
	<div class="form-group">
		<label for="balanceok" class="col-md-4 control-label">Balanceok</label>
		<div class="col-md-8">
			<input type="text" name="balanceok" value="<?php echo $this->input->post('balanceok'); ?>" class="form-control" id="balanceok" />
		</div>
	</div>
	<div class="form-group">
		<label for="refbancarias" class="col-md-4 control-label">Refbancarias</label>
		<div class="col-md-8">
			<input type="text" name="refbancarias" value="<?php echo $this->input->post('refbancarias'); ?>" class="form-control" id="refbancarias" />
		</div>
	</div>
	<div class="form-group">
		<label for="refbancariasobs" class="col-md-4 control-label">Refbancariasobs</label>
		<div class="col-md-8">
			<input type="text" name="refbancariasobs" value="<?php echo $this->input->post('refbancariasobs'); ?>" class="form-control" id="refbancariasobs" />
		</div>
	</div>
	<div class="form-group">
		<label for="refbancariasok" class="col-md-4 control-label">Refbancariasok</label>
		<div class="col-md-8">
			<input type="text" name="refbancariasok" value="<?php echo $this->input->post('refbancariasok'); ?>" class="form-control" id="refbancariasok" />
		</div>
	</div>
	<div class="form-group">
		<label for="antecedentes" class="col-md-4 control-label">Antecedentes</label>
		<div class="col-md-8">
			<input type="text" name="antecedentes" value="<?php echo $this->input->post('antecedentes'); ?>" class="form-control" id="antecedentes" />
		</div>
	</div>
	<div class="form-group">
		<label for="antecedentesobs" class="col-md-4 control-label">Antecedentesobs</label>
		<div class="col-md-8">
			<input type="text" name="antecedentesobs" value="<?php echo $this->input->post('antecedentesobs'); ?>" class="form-control" id="antecedentesobs" />
		</div>
	</div>
	<div class="form-group">
		<label for="antecedentesok" class="col-md-4 control-label">Antecedentesok</label>
		<div class="col-md-8">
			<input type="text" name="antecedentesok" value="<?php echo $this->input->post('antecedentesok'); ?>" class="form-control" id="antecedentesok" />
		</div>
	</div>
	<div class="form-group">
		<label for="refcomerciales" class="col-md-4 control-label">Refcomerciales</label>
		<div class="col-md-8">
			<input type="text" name="refcomerciales" value="<?php echo $this->input->post('refcomerciales'); ?>" class="form-control" id="refcomerciales" />
		</div>
	</div>
	<div class="form-group">
		<label for="refcomercialesobs" class="col-md-4 control-label">Refcomercialesobs</label>
		<div class="col-md-8">
			<input type="text" name="refcomercialesobs" value="<?php echo $this->input->post('refcomercialesobs'); ?>" class="form-control" id="refcomercialesobs" />
		</div>
	</div>
	<div class="form-group">
		<label for="refcomercialesok" class="col-md-4 control-label">Refcomercialesok</label>
		<div class="col-md-8">
			<input type="text" name="refcomercialesok" value="<?php echo $this->input->post('refcomercialesok'); ?>" class="form-control" id="refcomercialesok" />
		</div>
	</div>
	<div class="form-group">
		<label for="contastanciaiibb" class="col-md-4 control-label">Contastanciaiibb</label>
		<div class="col-md-8">
			<input type="text" name="contastanciaiibb" value="<?php echo $this->input->post('contastanciaiibb'); ?>" class="form-control" id="contastanciaiibb" />
		</div>
	</div>
	<div class="form-group">
		<label for="constanciaiibbobs" class="col-md-4 control-label">Constanciaiibbobs</label>
		<div class="col-md-8">
			<input type="text" name="constanciaiibbobs" value="<?php echo $this->input->post('constanciaiibbobs'); ?>" class="form-control" id="constanciaiibbobs" />
		</div>
	</div>
	<div class="form-group">
		<label for="constanciaiibbok" class="col-md-4 control-label">Constanciaiibbok</label>
		<div class="col-md-8">
			<input type="text" name="constanciaiibbok" value="<?php echo $this->input->post('constanciaiibbok'); ?>" class="form-control" id="constanciaiibbok" />
		</div>
	</div>
	<div class="form-group">
		<label for="infotecnica" class="col-md-4 control-label">Infotecnica</label>
		<div class="col-md-8">
			<input type="text" name="infotecnica" value="<?php echo $this->input->post('infotecnica'); ?>" class="form-control" id="infotecnica" />
		</div>
	</div>
	<div class="form-group">
		<label for="infotecnicaobs" class="col-md-4 control-label">Infotecnicaobs</label>
		<div class="col-md-8">
			<input type="text" name="infotecnicaobs" value="<?php echo $this->input->post('infotecnicaobs'); ?>" class="form-control" id="infotecnicaobs" />
		</div>
	</div>
	<div class="form-group">
		<label for="infotecnicaok" class="col-md-4 control-label">Infotecnicaok</label>
		<div class="col-md-8">
			<input type="text" name="infotecnicaok" value="<?php echo $this->input->post('infotecnicaok'); ?>" class="form-control" id="infotecnicaok" />
		</div>
	</div>
	<div class="form-group">
		<label for="autoevaluacion" class="col-md-4 control-label">Autoevaluacion</label>
		<div class="col-md-8">
			<input type="text" name="autoevaluacion" value="<?php echo $this->input->post('autoevaluacion'); ?>" class="form-control" id="autoevaluacion" />
		</div>
	</div>
	<div class="form-group">
		<label for="autoevaluacionobs" class="col-md-4 control-label">Autoevaluacionobs</label>
		<div class="col-md-8">
			<input type="text" name="autoevaluacionobs" value="<?php echo $this->input->post('autoevaluacionobs'); ?>" class="form-control" id="autoevaluacionobs" />
		</div>
	</div>
	<div class="form-group">
		<label for="autoevaluacionok" class="col-md-4 control-label">Autoevaluacionok</label>
		<div class="col-md-8">
			<input type="text" name="autoevaluacionok" value="<?php echo $this->input->post('autoevaluacionok'); ?>" class="form-control" id="autoevaluacionok" />
		</div>
	</div>
	<div class="form-group">
		<label for="constmonotirbuto" class="col-md-4 control-label">Constmonotirbuto</label>
		<div class="col-md-8">
			<input type="text" name="constmonotirbuto" value="<?php echo $this->input->post('constmonotirbuto'); ?>" class="form-control" id="constmonotirbuto" />
		</div>
	</div>
	<div class="form-group">
		<label for="constmonotributoobs" class="col-md-4 control-label">Constmonotributoobs</label>
		<div class="col-md-8">
			<input type="text" name="constmonotributoobs" value="<?php echo $this->input->post('constmonotributoobs'); ?>" class="form-control" id="constmonotributoobs" />
		</div>
	</div>
	<div class="form-group">
		<label for="constmonotributook" class="col-md-4 control-label">Constmonotributook</label>
		<div class="col-md-8">
			<input type="text" name="constmonotributook" value="<?php echo $this->input->post('constmonotributook'); ?>" class="form-control" id="constmonotributook" />
		</div>
	</div>
	<div class="form-group">
		<label for="titutlo" class="col-md-4 control-label">Titutlo</label>
		<div class="col-md-8">
			<input type="text" name="titutlo" value="<?php echo $this->input->post('titutlo'); ?>" class="form-control" id="titutlo" />
		</div>
	</div>
	<div class="form-group">
		<label for="tituloobs" class="col-md-4 control-label">Tituloobs</label>
		<div class="col-md-8">
			<input type="text" name="tituloobs" value="<?php echo $this->input->post('tituloobs'); ?>" class="form-control" id="tituloobs" />
		</div>
	</div>
	<div class="form-group">
		<label for="titulook" class="col-md-4 control-label">Titulook</label>
		<div class="col-md-8">
			<input type="text" name="titulook" value="<?php echo $this->input->post('titulook'); ?>" class="form-control" id="titulook" />
		</div>
	</div>
	<div class="form-group">
		<label for="matricula" class="col-md-4 control-label">Matricula</label>
		<div class="col-md-8">
			<input type="text" name="matricula" value="<?php echo $this->input->post('matricula'); ?>" class="form-control" id="matricula" />
		</div>
	</div>
	<div class="form-group">
		<label for="matriculaobs" class="col-md-4 control-label">Matriculaobs</label>
		<div class="col-md-8">
			<input type="text" name="matriculaobs" value="<?php echo $this->input->post('matriculaobs'); ?>" class="form-control" id="matriculaobs" />
		</div>
	</div>
	<div class="form-group">
		<label for="matriculaok" class="col-md-4 control-label">Matriculaok</label>
		<div class="col-md-8">
			<input type="text" name="matriculaok" value="<?php echo $this->input->post('matriculaok'); ?>" class="form-control" id="matriculaok" />
		</div>
	</div>
	<div class="form-group">
		<label for="antecedentesmono" class="col-md-4 control-label">Antecedentesmono</label>
		<div class="col-md-8">
			<input type="text" name="antecedentesmono" value="<?php echo $this->input->post('antecedentesmono'); ?>" class="form-control" id="antecedentesmono" />
		</div>
	</div>
	<div class="form-group">
		<label for="antecedentesmonoobs" class="col-md-4 control-label">Antecedentesmonoobs</label>
		<div class="col-md-8">
			<input type="text" name="antecedentesmonoobs" value="<?php echo $this->input->post('antecedentesmonoobs'); ?>" class="form-control" id="antecedentesmonoobs" />
		</div>
	</div>
	<div class="form-group">
		<label for="antecedentesmonook" class="col-md-4 control-label">Antecedentesmonook</label>
		<div class="col-md-8">
			<input type="text" name="antecedentesmonook" value="<?php echo $this->input->post('antecedentesmonook'); ?>" class="form-control" id="antecedentesmonook" />
		</div>
	</div>
	<div class="form-group">
		<label for="refcomercialesmono" class="col-md-4 control-label">Refcomercialesmono</label>
		<div class="col-md-8">
			<input type="text" name="refcomercialesmono" value="<?php echo $this->input->post('refcomercialesmono'); ?>" class="form-control" id="refcomercialesmono" />
		</div>
	</div>
	<div class="form-group">
		<label for="refcomercialesmonoobs" class="col-md-4 control-label">Refcomercialesmonoobs</label>
		<div class="col-md-8">
			<input type="text" name="refcomercialesmonoobs" value="<?php echo $this->input->post('refcomercialesmonoobs'); ?>" class="form-control" id="refcomercialesmonoobs" />
		</div>
	</div>
	<div class="form-group">
		<label for="refcomercialesmonook" class="col-md-4 control-label">Refcomercialesmonook</label>
		<div class="col-md-8">
			<input type="text" name="refcomercialesmonook" value="<?php echo $this->input->post('refcomercialesmonook'); ?>" class="form-control" id="refcomercialesmonook" />
		</div>
	</div>
	<div class="form-group">
		<label for="refbancariasmono" class="col-md-4 control-label">Refbancariasmono</label>
		<div class="col-md-8">
			<input type="text" name="refbancariasmono" value="<?php echo $this->input->post('refbancariasmono'); ?>" class="form-control" id="refbancariasmono" />
		</div>
	</div>
	<div class="form-group">
		<label for="refbancariasmonoobs" class="col-md-4 control-label">Refbancariasmonoobs</label>
		<div class="col-md-8">
			<input type="text" name="refbancariasmonoobs" value="<?php echo $this->input->post('refbancariasmonoobs'); ?>" class="form-control" id="refbancariasmonoobs" />
		</div>
	</div>
	<div class="form-group">
		<label for="refbancariasmonook" class="col-md-4 control-label">Refbancariasmonook</label>
		<div class="col-md-8">
			<input type="text" name="refbancariasmonook" value="<?php echo $this->input->post('refbancariasmonook'); ?>" class="form-control" id="refbancariasmonook" />
		</div>
	</div>
	<div class="form-group">
		<label for="completo" class="col-md-4 control-label">Completo</label>
		<div class="col-md-8">
			<input type="text" name="completo" value="<?php echo $this->input->post('completo'); ?>" class="form-control" id="completo" />
		</div>
	</div>
	<div class="form-group">
		<label for="aprobado" class="col-md-4 control-label">Aprobado</label>
		<div class="col-md-8">
			<input type="text" name="aprobado" value="<?php echo $this->input->post('aprobado'); ?>" class="form-control" id="aprobado" />
		</div>
	</div>
	<div class="form-group">
		<label for="idproveedor" class="col-md-4 control-label">Idproveedor</label>
		<div class="col-md-8">
			<input type="text" name="idproveedor" value="<?php echo $this->input->post('idproveedor'); ?>" class="form-control" id="idproveedor" />
		</div>
	</div>
	<div class="form-group">
		<label for="contratosocial" class="col-md-4 control-label">Contratosocial</label>
		<div class="col-md-8">
			<input type="text" name="contratosocial" value="<?php echo $this->input->post('contratosocial'); ?>" class="form-control" id="contratosocial" />
		</div>
	</div>
	<div class="form-group">
		<label for="contratosocialobs" class="col-md-4 control-label">Contratosocialobs</label>
		<div class="col-md-8">
			<input type="text" name="contratosocialobs" value="<?php echo $this->input->post('contratosocialobs'); ?>" class="form-control" id="contratosocialobs" />
		</div>
	</div>
	<div class="form-group">
		<label for="contratosocialok" class="col-md-4 control-label">Contratosocialok</label>
		<div class="col-md-8">
			<input type="text" name="contratosocialok" value="<?php echo $this->input->post('contratosocialok'); ?>" class="form-control" id="contratosocialok" />
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-8">
			<button type="submit" class="btn btn-success">Guardar</button>
        </div>
	</div>

<?php echo form_close(); ?>