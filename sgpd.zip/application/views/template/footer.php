    
  <footer id="footer" class="footer">
    <div class="text-center">
      <small>Desarrollo:  <a target="_blank" href="http://www.leyker.com.ar">Leyker Soft</a>  -  Cocyar S.A. - SGPD</small>
    </div>
  </footer>
</body>
</html>