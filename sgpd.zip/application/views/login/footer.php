    <script src="<?php base_url();?>assets/js/login.js"></script>	
    <script src="<?php base_url();?>assets/js/jquery-3.4.1.min.js"></script>
  </body>
</html>

