<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title><?php //echo $titulo; ?></title>

	<link rel="stylesheet" href="<?php base_url();?>assets/css/login.css">
	<link rel="stylesheet" href="<?php base_url();?>assets/css/opensans.css">
	<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.min.css"); ?>" />
    <link rel="stylesheet" href="<?php echo base_url("assets/css/sticky-style.css"); ?>" />
    <link rel="stylesheet" href="<?php echo base_url("assets/css/login.css"); ?>" />
    <link rel="stylesheet" href="<?php echo base_url("assets/css/simple-sidebar.css"); ?>" />
    <link rel="stylesheet" href="<?php echo base_url("assets/css/datepicker.css"); ?>" />
    <link rel="stylesheet" href="<?php echo base_url("assets/css/prettify.css"); ?>" />

</head>
<body>
